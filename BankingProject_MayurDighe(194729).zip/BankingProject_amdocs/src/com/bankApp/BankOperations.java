package com.bankApp;

import java.util.ArrayList;
import java.util.Scanner;

public class BankOperations {
	String name, city;
	Scanner sc = new Scanner(System.in);

	ArrayList<Account> ls = new ArrayList<>();
	
	void OpenAccount() {
		
		System.out.println("-----Enter Your Deatils-----");
		System.out.println("Enter Your Name");
		name = sc.next();
		System.out.println("Enter City");
		city = sc.next();
		
		Account ac = new Account(name, city);
		/*ls.add(new Account("Mayur", "pune"));
		ls.add(new Account("darshan","nashik"));
		ls.add(new Account("akshay","shrirampur"));*/
		ls.add(ac);
		
		System.out.println("Account Created sucessfully !!!!");
		System.out.println("Your account number is: "+ac.getAccno());
	}

	void listOfCustomer() {
		System.out.println("Enter Password");
		int pass=sc.nextInt();
		if(pass==1234) {
			System.out.println("--------List Of Customer--------");
			for (Account acc : ls) {
				System.out.println("Account Number :" + acc.getAccno());
				System.out.println("Name: " + acc.getName());
				System.out.println("City: " + acc.getCity());
				System.out.println("Balance: " + acc.getBal());
				System.out.println("---------------------------------------------------------");
			}
		}
		else
			System.out.println("Oops...Check Your credential once.!!!!");
		
	}
	
	void deposite() {
		boolean found=false;
		System.out.println("Enter Your account number");
		int accno=sc.nextInt();
		for(Account acc:ls) {
			if(acc.getAccno()==accno){
				found=true;
				System.out.println("----------Welcome "+acc.getName()+"----------");
				System.out.println("Enter amount to deposite");
				int amount=sc.nextInt();
				acc.setBal(acc.getBal()+amount);
				System.out.println("Amount Deposited sucessfully !!!!..");
				System.out.println("Your updated balance is: "+acc.getBal()+"cr");
				break;
			}
		}
		if(found==false) {
			System.out.println("Oops..Please check your account number");
		}	
	}
	
	void withdraw() {
		boolean found=false;
		System.out.println("Enter your account number");
		int accno=sc.nextInt();
		for(Account acc:ls) {
			if(accno==acc.getAccno()) {
				found=true;
				System.out.println("----------Welcome "+acc.getName()+"----------");
				System.out.println("Enter amount to withdrow");
				int amount=sc.nextInt();
					if(acc.getBal()<amount) {
						System.out.println("Oops....Your Balance is Low");
					}
					else {
						acc.setBal(acc.getBal()-amount);
						System.out.println("Balance withdrow sucessfully !!!!");
						System.out.println("Your updated balance is: "+acc.getBal());
						break;
					}
			
			}
		}
		if(found==false) {
			System.out.println("Oops..Please check your account number");
		}
	}
	
	void balanceEnquiry() {
		boolean found=false;
		System.out.println("Enter your account number");
		int accno=sc.nextInt();
		for(Account acc:ls) {
			if(acc.getAccno()==accno){
				found=true;
				System.out.println("----------Welcome "+acc.getName()+"----------");
				System.out.println("Your balance is: "+acc.getBal()+"cr");
				break;
			}
		}
		if(found==false) {
			System.out.println("Oops..Please check your account number");
		}	
	}
	
}
