package com.bankApp;

import java.util.Scanner;

public class BankingApplication {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
		System.out.println("Select Your Operation");
		System.out.println("1.Open Account");
		System.out.println("2.Deposite");
		System.out.println("3.Withdraw");
		System.out.println("4.Balance Enquiry");
		System.out.println("5.List of Customers");
		System.out.println("6.Exit");
		
		BankOperations bank=new BankOperations();
		
		int choice;
		do {
			System.out.println("Enter Your choice here..");
			choice=sc.nextInt();
				switch(choice) {
					case 1:
						bank.OpenAccount();
						break;
						
					case 2:
						bank.deposite();
						break;
						
					case 3:
						bank.withdraw();
						break;
						
					case 4:
						bank.balanceEnquiry();
						break;
						
					case 5:
						bank.listOfCustomer();
						break;
						
					case 6:
						System.out.println("--------Thank You for visiting us--------");
						break;
						
					default:
							System.out.println("Oops...Invalid Choice");
							break;
				}
			
		}
		
		while(choice!=6) ;
			
	}

}
