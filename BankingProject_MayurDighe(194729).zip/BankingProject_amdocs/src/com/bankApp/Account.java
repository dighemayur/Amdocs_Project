package com.bankApp;

public class Account {
	private int accno;
	private static int staccno = 1001;
	private String name;
	private String city;
	private float bal;
	private static float stbal = 1000;

	public Account(String name, String city) {
		this.name = name;
		this.city = city;
		this.bal = stbal;
		this.accno = staccno++;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public static int getStaccno() {
		return staccno;
	}

	public static void setStaccno(int staccno) {
		Account.staccno = staccno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public float getBal() {
		return bal;
	}

	public void setBal(float bal) {
		this.bal = bal;
	}

	public static float getStbal() {
		return stbal;
	}

	public static void setStbal(float stbal) {
		Account.stbal = stbal;
	}

	
}
